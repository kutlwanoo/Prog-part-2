﻿using System;

namespace Assigntment_1
{
    public class Steps
    {
        public string Description { get; set; }
        public Steps(string description)
        { Description = description; }

        internal static void Add(Steps steps)
        {
            throw new NotImplementedException();
        }

        internal static object Clear()
        {
            throw new NotImplementedException();
        }
    }
}
