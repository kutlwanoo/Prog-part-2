﻿namespace Assigntment_1
{
    public class Ingredients
    {
        public Ingredients(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
        }

        public string Name { get; set; } //These are the name of the ingredients
        public double Quantity { get; set; }    // The quantity you wish to present 
        public string Unit { get; set; }    // The unit of measurement you wish to have
    }
}
