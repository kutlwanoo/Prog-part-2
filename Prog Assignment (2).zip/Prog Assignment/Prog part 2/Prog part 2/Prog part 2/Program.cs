﻿using System;
using System.Collections.Generic;
using System.Linq;

class Ingredient
{
    public string Name { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }
}

class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; }

    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
    }

    public int CalculateTotalCalories()
    {
        return Ingredients.Sum(i => i.Calories);
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<Recipe> recipes = new List<Recipe>();

        while (true)
        {
            Console.WriteLine("Enter the name of the recipe (or type 'exit' to stop):");
            string recipeName = Console.ReadLine();

            if (recipeName.ToLower() == "exit")
            {
                break;
            }

            Recipe newRecipe = new Recipe(recipeName);

            while (true)
            {
                Console.WriteLine("Enter the name of an ingredient:");
                string ingredientName = Console.ReadLine();

                if (string.IsNullOrEmpty(ingredientName))
                {
                    break;
                }

                Console.WriteLine("Enter the number of calories:");
                int calories = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter the food group:");
                string foodGroup = Console.ReadLine();

                Ingredient newIngredient = new Ingredient
                {
                    Name = ingredientName,
                    Calories = calories,
                    FoodGroup = foodGroup
                };

                newRecipe.Ingredients.Add(newIngredient);
            }

            recipes.Add(newRecipe);
        }

        Console.WriteLine("Recipes:");
        foreach (Recipe recipe in recipes.OrderBy(r => r.Name))
        {
            Console.WriteLine(recipe.Name);
        }

        Console.WriteLine("Choose a recipe to display:");
        string selectedRecipeName = Console.ReadLine();

        Recipe selectedRecipe = recipes.Find(r => r.Name == selectedRecipeName);

        if (selectedRecipe != null)
        {
            Console.WriteLine("Ingredients in " + selectedRecipe.Name + ":");
            foreach (Ingredient ingredient in selectedRecipe.Ingredients)
            {
                Console.WriteLine(ingredient.Name + " - Calories: " + ingredient.Calories + " - Food Group: " + ingredient.FoodGroup);
            }

            int totalCalories = selectedRecipe.CalculateTotalCalories();
            Console.WriteLine("Total Calories: " + totalCalories);

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Total calories exceed 300!");
            }
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }
    }
}
